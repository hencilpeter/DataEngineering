class ThreadConfigurationName:
    THREAD_CONFIG_SECTION = "thread"
    THREAD_MANAGER = "thread_manager"
    MESSAGE_RECEIVER = "message_receiver"
    GARBAGE_COLLECTOR_THREAD_NAME = "garbage_collector"
    THREAD_LIFE_NOTIFIER_THREAD_NAME = "thread_life_notifier"
    TRANSACTION_DATA_PROCESSOR = "transaction_data-processor"
    SLEEP_INTERVAL_IN_SECONDS = "sleep_interval_in_seconds"
    THREAD_COUNT = "thread_count"
    TABLE_LIST = "table_list"

    def __init__(self):
        pass
