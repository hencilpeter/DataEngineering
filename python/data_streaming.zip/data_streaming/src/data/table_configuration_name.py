class TableConfigurationName:
    COLUMNS = "columns"
    OUTFILE_DELIMITER = "outfile_delimiter"
    HDFS_WRITE_MODE = "hdfs_write_mode"
    HDFS_WRITE_FORMAT = "hdfs_write_format"
    HDFS_DATA_PATH = "hdfs_data_path"
    PARTITION_FREQUENCY = "partition_frequency"

    def __init__(self):
        pass
