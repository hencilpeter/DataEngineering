class ApplicationConfigurationValue:
    RUNNING_MODE_DEBUG = "DEBUG"
    RUNNING_MODE_NORMAL = "NORMAL"

    def __init__(self):
        pass
