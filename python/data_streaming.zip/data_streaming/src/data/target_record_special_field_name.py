class TargetRecordSpecialFieldName:
    # special fields
    SOURCE_TABLE_OPERATION = "source_table_operation"
    KAKFA_TOPIC = "kakfa-topic"
    KAFKA_TOPIC_OFFSET = "kafka_topic_offset"
    MESSAGE_TIMESTAMP = "message_timestamp"
    TABLE_NAME = "table_name"

    def __init__(self):
        pass
