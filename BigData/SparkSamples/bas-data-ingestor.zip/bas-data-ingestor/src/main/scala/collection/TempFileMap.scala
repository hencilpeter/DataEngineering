/**
  * @author Hencil Peter
  *
  */

package collection

object TempFileMap {
  val fileAndId = Map( "AccountSampleData" -> 1, "IBRDLoansHistoricalSampleData" -> 2 )
}