package reader

class ParquetReader {
  
}